-- MySQL dump 10.13  Distrib 5.5.43, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: feedback
-- ------------------------------------------------------
-- Server version	5.5.43-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `feedback`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `feedback` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci */;

USE `feedback`;

--
-- Table structure for table `hotels`
--

DROP TABLE IF EXISTS `hotels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hotels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `logo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `exceptions` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hotels`
--

LOCK TABLES `hotels` WRITE;
/*!40000 ALTER TABLE `hotels` DISABLE KEYS */;
INSERT INTO `hotels` VALUES (1,'sunrise','/files/uploads/6ade02bd0d9e5a2ee4cdd978949cc0fb6bbcf673.png','',NULL),(2,'sentido','uploads/sentido.jpg',NULL,NULL);
/*!40000 ALTER TABLE `hotels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `languages`
--

DROP TABLE IF EXISTS `languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `flag` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `languages`
--

LOCK TABLES `languages` WRITE;
/*!40000 ALTER TABLE `languages` DISABLE KEYS */;
INSERT INTO `languages` VALUES (1,'English','/files/uploads/ddf547d58e2c295e1f2fd04ad573f9236341d798.gif'),(2,'German','/files/uploads/8d7882dc607adefb86a4ca5d14c35b451c174543.gif');
/*!40000 ALTER TABLE `languages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_options`
--

DROP TABLE IF EXISTS `question_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `question_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question_id` int(11) NOT NULL,
  `option` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `flag` int(2) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question_options`
--

LOCK TABLES `question_options` WRITE;
/*!40000 ALTER TABLE `question_options` DISABLE KEYS */;
INSERT INTO `question_options` VALUES (1,7,'SUNRISE Select Royal Makadi Resort\r\n',NULL,NULL),(2,7,'SUNRISE Select Garden Beach Resort & Spa\r\n',NULL,NULL),(3,7,'SUNRISE Grand Select Crystal Bay Resort\r\n',NULL,NULL),(4,7,'SUNRISE Holidays Resort\r\n',NULL,NULL),(5,7,'SUNRISE Grand Select Arabian Beach Resort\r\n',NULL,NULL),(6,7,'SUNRISE Grand Select Montemare Resort\r\n',NULL,NULL),(7,7,'Festival Shedwan Golden Beach Resort\r\n',NULL,NULL),(8,7,'Festival Le Jardin Resort\r\n',NULL,NULL),(9,7,'Festival Riviera Resort\r\n',NULL,NULL),(10,7,'SENTIDO Mamlouk Palace Resort\r\n',NULL,NULL);
/*!40000 ALTER TABLE `question_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_text`
--

DROP TABLE IF EXISTS `question_text`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `question_text` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `language_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question_text`
--

LOCK TABLES `question_text` WRITE;
/*!40000 ALTER TABLE `question_text` DISABLE KEYS */;
INSERT INTO `question_text` VALUES (3,'How satisfied are you?',1,1),(4,'Wie zufrieden sind Sie?',2,1),(5,'How satisfied are you?',1,2),(6,'Wie zufrieden sind Sie?',2,2),(7,'How satisfied are you?',1,3),(8,'Wie zufrieden sind Sie?',2,3),(9,'How satisfied are you?',1,4),(10,'Wie zufrieden sind Sie?',2,4),(11,'How satisfied are you?',1,5),(12,'Wie zufrieden sind Sie?',2,5),(13,'How satisfied are you?',1,6),(14,'Wie zufrieden sind Sie?',2,6),(15,'Have you been to one of our SUNRISE / SENTIDO / Festival / smartline / SunConnect resorts and cruises before?',1,7),(16,'Have you been to one of our SUNRISE / SENTIDO / Festival / smartline / SunConnect resorts and cruises before?',2,7),(29,'eeeeeeeeeed',1,0),(30,'ggggggggggg',2,0);
/*!40000 ALTER TABLE `question_text` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_title`
--

DROP TABLE IF EXISTS `question_title`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `question_title` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `language_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question_title`
--

LOCK TABLES `question_title` WRITE;
/*!40000 ALTER TABLE `question_title` DISABLE KEYS */;
INSERT INTO `question_title` VALUES (1,'room',1,1),(2,'Zimmer',2,1),(3,'Reception',1,2),(4,'Rezeption',2,2),(5,'Housekeeping',1,3),(6,'Housekeeping',2,3),(7,'WiFi',1,4),(8,'WiFi',2,4),(9,'Service',1,5),(10,'Service',2,5),(11,'Drinks',1,6),(12,'Spisen',2,6),(13,'Marketing',1,7),(14,'Marketing',2,7),(27,'ee',1,0),(28,'gg',2,0);
/*!40000 ALTER TABLE `question_title` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) NOT NULL,
  `option` tinyint(1) NOT NULL DEFAULT '0',
  `deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `questions`
--

LOCK TABLES `questions` WRITE;
/*!40000 ALTER TABLE `questions` DISABLE KEYS */;
INSERT INTO `questions` VALUES (1,1,0,NULL),(2,1,0,NULL),(3,1,0,NULL),(4,1,0,NULL),(5,2,0,NULL),(6,2,0,NULL),(7,3,1,NULL);
/*!40000 ALTER TABLE `questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ratings`
--

DROP TABLE IF EXISTS `ratings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ratings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `rate` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ratings`
--

LOCK TABLES `ratings` WRITE;
/*!40000 ALTER TABLE `ratings` DISABLE KEYS */;
/*!40000 ALTER TABLE `ratings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `score_question`
--

DROP TABLE IF EXISTS `score_question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `score_question` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `score_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `score` int(5) NOT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `score_question`
--

LOCK TABLES `score_question` WRITE;
/*!40000 ALTER TABLE `score_question` DISABLE KEYS */;
INSERT INTO `score_question` VALUES (1,1,1,1,'44'),(2,1,2,2,'j'),(3,1,3,4,''),(4,1,4,5,''),(5,1,5,5,''),(6,1,6,4,''),(7,2,1,3,''),(8,2,1,5,''),(9,4,5,3,''),(10,8,1,5,'fds'),(11,9,2,4,'tr'),(12,10,5,4,'fds'),(13,11,6,2,'\r\n\';'),(14,12,5,3,'j'),(15,13,5,2,'kj');
/*!40000 ALTER TABLE `score_question` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `score_select`
--

DROP TABLE IF EXISTS `score_select`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `score_select` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `score_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `selections` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `score_select`
--

LOCK TABLES `score_select` WRITE;
/*!40000 ALTER TABLE `score_select` DISABLE KEYS */;
INSERT INTO `score_select` VALUES (1,3,7,'on,on,on',NULL),(2,3,7,'1,2,5',NULL),(3,3,7,'1,2,5',NULL),(4,4,7,'',NULL),(5,4,7,'2,5',NULL),(6,4,7,'1',NULL),(7,4,7,'1',NULL),(8,4,7,'2',NULL),(9,4,7,'5',NULL),(10,5,7,'2',NULL),(11,5,7,'2',NULL),(12,6,7,'2',NULL),(13,6,7,'4,10',NULL),(14,6,7,'4',NULL),(15,6,7,'',NULL),(16,6,7,'2,5',NULL),(17,6,7,'5,8',NULL),(18,6,7,'8,10',NULL),(19,6,7,'',NULL),(20,6,7,'',NULL),(21,6,7,'',NULL),(22,7,7,'2,5',NULL),(23,14,7,'10',NULL),(24,15,7,'10',NULL);
/*!40000 ALTER TABLE `score_select` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scores`
--

DROP TABLE IF EXISTS `scores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language_id` int(11) DEFAULT NULL,
  `nationality` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `room_no` int(6) DEFAULT NULL,
  `hotel_id` int(11) DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scores`
--

LOCK TABLES `scores` WRITE;
/*!40000 ALTER TABLE `scores` DISABLE KEYS */;
INSERT INTO `scores` VALUES (1,1,'natio',24710,1,'b@a.tio','satio',1),(2,NULL,NULL,NULL,NULL,NULL,NULL,0),(3,NULL,NULL,NULL,NULL,NULL,NULL,0),(4,NULL,NULL,NULL,NULL,NULL,NULL,0),(5,NULL,NULL,NULL,NULL,NULL,NULL,0),(6,NULL,NULL,NULL,NULL,NULL,NULL,0),(7,NULL,NULL,NULL,NULL,NULL,NULL,0),(8,NULL,NULL,NULL,NULL,NULL,NULL,0),(9,1,'natio',54710,1,'f@t.io','katio',1),(10,NULL,NULL,NULL,NULL,NULL,NULL,0),(11,NULL,NULL,NULL,NULL,NULL,NULL,0),(12,NULL,NULL,NULL,NULL,NULL,NULL,0),(13,NULL,NULL,NULL,NULL,NULL,NULL,0),(14,NULL,NULL,NULL,NULL,NULL,NULL,0),(15,NULL,NULL,NULL,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `scores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `section_name`
--

DROP TABLE IF EXISTS `section_name`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `section_name` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `section_name`
--

LOCK TABLES `section_name` WRITE;
/*!40000 ALTER TABLE `section_name` DISABLE KEYS */;
INSERT INTO `section_name` VALUES (9,1,1,'Hotel'),(10,1,2,'Hotel'),(11,2,1,'Restaurant'),(12,2,2,'Restaurantt'),(13,3,1,'More'),(14,3,2,'Mehr');
/*!40000 ALTER TABLE `section_name` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES (1,'hotel section'),(2,'restaurant section'),(3,'etc.');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `texts`
--

DROP TABLE IF EXISTS `texts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `texts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `texts`
--

LOCK TABLES `texts` WRITE;
/*!40000 ALTER TABLE `texts` DISABLE KEYS */;
INSERT INTO `texts` VALUES (1,'feedback title'),(2,'more'),(3,'back'),(4,'done'),(5,'rating'),(6,'Language selection'),(7,'select language'),(8,'Home'),(9,'Your message '),(10,'Complete feedback'),(11,'Optional information'),(12,'send'),(13,'Nationality'),(14,'What is your nationality?'),(15,'name required'),(16,'comments'),(17,'What is your phone number?'),(18,'E-Mail'),(19,'What is your e-mail address?'),(20,'Room #'),(21,'What is your room number?'),(22,'roon number required'),(23,'email required'),(24,'field required'),(25,'please click here for comments'),(26,'Rate next section'),(27,'Please use the stars!'),(28,'absolutely not satisfied'),(29,'not satisfied'),(30,'about average'),(31,'satisfied'),(32,'absolutely satisfied'),(33,'rate one star!'),(34,'We want you to be satisfied.'),(35,'This site uses cookies.'),(36,'Thank you!'),(37,'OK'),(38,'How satisfied are you?'),(39,'Yes'),(40,'No');
/*!40000 ALTER TABLE `texts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `texts_text`
--

DROP TABLE IF EXISTS `texts_text`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `texts_text` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language_id` int(11) NOT NULL,
  `text_id` int(11) NOT NULL,
  `text` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `texts_text`
--

LOCK TABLES `texts_text` WRITE;
/*!40000 ALTER TABLE `texts_text` DISABLE KEYS */;
INSERT INTO `texts_text` VALUES (1,1,1,'Feedback to the management ...'),(2,2,1,'Ihr Feedback ans Management ...'),(3,1,2,'more'),(4,2,2,'mehr'),(5,1,3,'back'),(6,2,3,'zurück'),(7,1,4,'done'),(8,2,4,'fertig'),(9,1,5,'Your rating'),(10,2,5,'Your rating'),(11,1,6,'Language selection'),(12,2,6,'Language selection'),(13,1,7,'Please select your language'),(14,2,7,'Please select your language'),(15,1,8,'Home'),(16,2,8,'Home'),(17,1,9,'Your message will now be forwarded directly to the management...'),(18,2,9,'Your message will now be forwarded directly to the management...'),(19,1,10,'Complete feedback'),(20,2,10,'Complete feedback'),(21,1,11,'Optional information'),(22,2,11,'Optional information'),(23,1,12,'send'),(24,2,12,'send'),(25,1,13,'Nationality'),(26,2,13,'Nationality'),(27,1,14,'What is your nationality?'),(28,2,14,'What is your nationality?'),(29,1,15,'We constantly try to improve our services, please help us by providing your name. Thank you!'),(30,2,15,'We constantly try to improve our services, please help us by providing your name. Thank you!'),(31,1,16,'comments'),(32,2,16,'comments'),(33,1,17,'What is your phone number?'),(34,2,17,'What is your phone number?'),(35,1,18,'E-Mail'),(36,2,18,'E-Mail'),(37,1,19,'What is your e-mail address?'),(38,2,19,'What is your e-mail address?'),(39,1,20,'Room #'),(40,2,20,'Room #'),(41,1,21,'What is your room number?'),(42,2,21,'What is your room number?'),(45,1,22,'We constantly try to improve our services, please help us by providing your room number. Thank you!'),(46,2,22,'We constantly try to improve our services, please help us by providing your room number. Thank you!'),(47,1,23,'Please enter a valid e-mail address or your name and phone number so we can contact you.'),(48,2,23,'Please enter a valid e-mail address or your name and phone number so we can contact you.'),(49,1,24,'This field is required.'),(50,2,24,'This field is required.'),(51,1,25,'please click here for comments'),(52,2,25,'please click here for comments'),(53,1,26,'Rate next section'),(54,2,26,'Rate next section'),(55,1,27,'Please use the stars!'),(56,2,27,'Please use the stars!'),(57,1,28,'absolutely not satisfied'),(58,2,28,'absolutely not satisfied'),(59,1,29,'not satisfied'),(60,2,29,'not satisfied'),(61,1,30,'about average'),(62,2,30,'about average'),(63,1,31,'satisfied'),(64,2,31,'satisfied'),(65,1,32,'absolutely satisfied'),(66,2,32,'absolutely satisfied'),(67,1,33,'rate one star!'),(68,2,33,'rate one star!'),(69,1,34,'We want you to be satisfied.'),(70,2,34,'We want you to be satisfied.'),(71,1,35,'This site uses cookies.'),(72,2,35,'This site uses cookies.'),(73,1,36,'Thank you!'),(74,2,36,'Thank you!'),(75,1,37,'OK'),(76,2,37,'OK'),(77,1,38,'How satisfied are you?'),(78,2,38,'How satisfied are you?'),(79,1,39,'Yes'),(80,2,39,'Yes'),(81,1,40,'No'),(82,2,40,'No');
/*!40000 ALTER TABLE `texts_text` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `admin` tinyint(1) NOT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'nq','admin','pass','em',1,NULL,1,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_hotels`
--

DROP TABLE IF EXISTS `users_hotels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_hotels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `hotel_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='many to many relation';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_hotels`
--

LOCK TABLES `users_hotels` WRITE;
/*!40000 ALTER TABLE `users_hotels` DISABLE KEYS */;
INSERT INTO `users_hotels` VALUES (64,1,1),(65,1,2);
/*!40000 ALTER TABLE `users_hotels` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-05-07 15:23:50
